import java.util.*;
class AreaShape{
//Area of squre
int area(int l)
{
return(l*l);
}
//Area of rectangle
int area(int l , int b)
{
return(l*b);
}
//Area of cuboid
int area(int l ,int b ,int h)
{
return((2*l*b)+(2*l*h)+(2*h*b));
}
public static void main(String[]args)
{
AreaShape s = new AreaShape ();
System.out.println("Area of squre:"+s.area(6));
System.out.println("Area of rectangle:"+s.area(6,4 ));
System.out.println("Area of cuboid :"+s.area(6,4,9));
}
}
