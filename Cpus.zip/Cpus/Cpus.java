import java.util.Scanner;
class Cpu{
  int price=3699;
  class Processor{
  int noofcores=4;
  String manufacturer="intel corp";
  void display(){
  System.out.print("Number of cores = "+noofcores);
  System.out.print("\nManufacturer = "+manufacturer);
   }
   }
   
void display()
{
 
  Processor p=new Processor();
  p.display();
  {  
   System.out.print("\nPrice = "+ price); 
}
}

    
static class Ram{
  int memory=8; 
  String manufacturer="apple";
  void display()
  {
  System.out.print("\nMemory = "+ memory);
  System.out.print("\nManufacturer = "+ manufacturer+"\n");  
  }
}
}
    
class Cpus{
  public static void main(String[] args)
  {
    Cpu c1=new Cpu();
    c1.display();
    Cpu.Ram r1=new Cpu.Ram();
    r1.display();
  }
}
    
    
      
