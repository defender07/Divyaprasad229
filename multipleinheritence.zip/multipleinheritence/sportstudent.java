interface Student{
int score=10;
void  displayScore();
}
interface Sports{
int score=25;
void displaySportScore();
}
class result implements Student,Sports{
public void displayScore(){
System.out.println("Academic Score: " + Student.score);
}
public void displaySportScore(){
System.out.println("Sports score: " + Sport.score);
}
}
class SportStudent{
public static void main(String[] args){
result r=new result();
r.displayScore();
r.displaySportScore();
}
}


