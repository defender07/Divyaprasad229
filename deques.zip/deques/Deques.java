import java.util.*;

public class Deques{
 public static void main(String[] args){
 Deque<String> deque=new ArrayDeque<String>();
 
 deque.add("a");
 deque.add("b");
 deque.add("c");
 deque.add("d");
 deque.add("e");
 
 System.out.println("\nvalues in queue:");
for(String str:deque)
{
System.out.print(str+" ");
}
deque.addFirst("z");
System.out.println("\n\nqueue after inserting at first:");
for(String str:deque)
{
System.out.print(str+" ");
}
deque.remove();
System.out.println("\n\nqueue after deleting at first:");
for(String str:deque)
{
System.out.print(str+" ");
}
deque.addLast("x");
System.out.println("\n\nqueue after inserting at last:");
for(String str:deque)
{
System.out.print(str+" ");
}
deque.clear();
deque.add("k\n");
System.out.println("\n\nqueue after clearing and inserting a new element:");
for(String str:deque)
{
System.out.print(str+" ");
}
}
}
